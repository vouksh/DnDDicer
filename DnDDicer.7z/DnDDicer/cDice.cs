﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml.Schema;
using System.IO;

namespace DnDDicer
{
	public class DiceSaver
	{
		private string dataFolder = "./DiceData/";
		private string fileExt = ".dce";
		public string profileName = "";
		private string fileName = "";
		public DiceSaver(string _profile)
		{
			profileName = _profile;
			fileName = dataFolder + profileName + fileExt;
			DirectoryInfo di = new DirectoryInfo(dataFolder);
			if(!di.Exists)
			{
				di.Create();
			}
		}
		public void LoadFile(ref Dice diceData)
		{
			if (WaitForFile(fileName))
			{
				Dice tDice;
				XmlSerializer x = new XmlSerializer(typeof(Dice));
				try
				{
					FileStream fs = new FileStream(fileName, FileMode.Open);
					tDice = (Dice)x.Deserialize(fs);
					fs.Close();
				}
				catch (FileNotFoundException ex)
				{
					tDice = new Dice();
					Die tDie = new Die("Default Dice", 20, 1, false, 0);
					tDice.Add(tDie);
				}
				diceData = tDice;
			} else
			{
				throw new Exception("Couldn't unlock the file...");
			}
		}
		public void SaveFile(Dice diceData)
		{
			if (WaitForFile(fileName))
			{
				try { File.Delete(fileName); }
				catch (FileNotFoundException ex)
				{
					//Do nothing, file doesn't exist
				}
				XmlSerializer x = new XmlSerializer(typeof(Dice));
				TextWriter w = new StreamWriter(fileName);
				x.Serialize(w, diceData);
				w.Flush();
				w.Close();
			}
			else
			{
				throw new Exception("Couldn't unlock the file...");
			}
		}
		bool WaitForFile(string fullPath)
		{
			if (File.Exists(fullPath))
			{
				int numTries = 0;
				while (true)
				{
					++numTries;
					try
					{
						// Attempt to open the file exclusively.
						using (FileStream fs = new FileStream(fullPath,
							FileMode.Open, FileAccess.ReadWrite,
							FileShare.None, 100))
						{
							fs.ReadByte();

							// If we got this far the file is ready
							break;
						}
					}
					catch (Exception ex)
					{
						if (numTries > 10)
						{
							return false;
							throw new Exception("Tries exhausted. File is still locked.");
						}

						// Wait for the lock to be released
						System.Threading.Thread.Sleep(500);
					}
				}
				return true;
			}
			else
			{
				return true;
			}
		} 
	}

	public class Dice : ICollection
	{
		public string CollectionName;
		public List<Die> diceArray = new List<Die>();
		public Die this[int index]
		{
			get { return (Die)diceArray[index]; }
		}

		public void CopyTo(Array a, int index)
		{
		}

		public int Count
		{
			get { return diceArray.Count; }
		}
		public object SyncRoot
		{
			get { return this; }
		}
		public bool IsSynchronized
		{
			get { return false; }
		}
		public IEnumerator GetEnumerator()
		{
			return diceArray.GetEnumerator();
		}
		public void Add(Die newDie)
		{
			diceArray.Add(newDie);
		}
		public void Remove(Guid diceId)
		{
			var tDie = from d in diceArray
					   where d.UID == diceId
					   select d;
			diceArray.Remove(tDie.First<Die>());
		}
	}
	public class Die
	{
		public Guid UID;
		public int Size;
		public int Count;
		public string Name;
		public int AddAmount;
		public bool isEmpowered;
		public double LastRoll;
		public Die()
		{
			UID = Guid.NewGuid();
		}
		public Die(string Name, int Size, int Count, bool Empowered, int Added)
		{
			this.Name = Name;
			this.Size = Size;
			this.Count = Count;
			isEmpowered = Empowered;
			AddAmount = Added;
			LastRoll = 0;
			UID = Guid.NewGuid();
		}
	}
}
