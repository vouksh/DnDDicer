﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DnDDicer
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public Dice DiceData;
		public DicerSettings Settings;
		public DiceSaver Saver;
		public MainWindow()
		{
			InitializeComponent();
			Settings = new DicerSettings();
			Saver = new DiceSaver(Settings.Data.ProfileName);
			Saver.LoadFile(ref DiceData);
		}

		private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			Saver.SaveFile(DiceData);
			Settings.SaveSettings();
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			PopulateRows();
			this.Title = "D&D Dicer (" + Settings.Data.ProfileName + ")";
		}
		private void ReloadSettings()
		{
			Settings.LoadSettings();
			Saver = new DiceSaver(Settings.Data.ProfileName);
			Saver.LoadFile(ref DiceData);
			this.Title = "D&D Dicer (" + Settings.Data.ProfileName + ")";
		}
		private void addNew_Click(object sender, RoutedEventArgs e)
		{
			Die tDie = new Die("New Dice", 20, 1, false, 0);
			DiceData.Add(tDie);
			PopulateRows();
		}

		private void NewRow_DiceUpdated(object sender, DiceEventArgs e)
		{
			DiceData = e.DiceData;
			if (e.DoRefresh)
				PopulateRows();
		}
		private void SettingsWindow_SettingsUpdated(object sender, SettingsEventArgs e)
		{
			ReloadSettings();
			PopulateRows();
		}
		/*private void SettingsWindow_Closed(object sender, RoutedEventArgs e)
		{
			ReloadSettings();
			PopulateRows();
		}*/
		private void PopulateRows()
		{
			DiceRow newRow;
			int i = 0;
			DiceGrid.Children.Clear();
			foreach (Die fDie in DiceData)
			{
				newRow = new DiceRow();
				newRow.diceArray = DiceData;
				newRow.Name = "DiceRow" + i;
				newRow.thisDice = fDie;
				newRow.Margin = new Thickness(0, (DiceGrid.Children.Count * 60) + 5, 0, 0);
				newRow.VerticalAlignment = VerticalAlignment.Top;
				newRow.BorderThickness = new Thickness(0, 1, 0, 1);
				newRow.BorderBrush = Brushes.Black;
				if (DiceGrid.Children.Count % 2 != 0)
				{
					//SolidColorBrush greybg = new SolidColorBrush(Colors.LightGray);
					SolidColorBrush orColor = new SolidColorBrush((Color)ColorConverter.ConvertFromString(Settings.Data.OffRowColor));
					orColor.Opacity = 1;
					newRow.Background = orColor;
				} else
				{
					SolidColorBrush mrColor = new SolidColorBrush((Color)ColorConverter.ConvertFromString(Settings.Data.MainRowColor));
					mrColor.Opacity = 1;
					newRow.Background = mrColor;
				}
				DiceGrid.Children.Add(newRow);
				newRow.DiceUpdated += new EventHandler<DiceEventArgs>(NewRow_DiceUpdated);
				i++;
			}
		}
		

		private void resetRolls_Click(object sender, RoutedEventArgs e)
		{
			for(int i = 0; i< DiceData.Count;i++)
			{
				DiceData[i].LastRoll = 0;
			}
			PopulateRows();
		}

		private void settingsBtn_Click(object sender, RoutedEventArgs e)
		{
			SettingsWindow sw = new SettingsWindow();
			sw.SettingsUpdated += new EventHandler<SettingsEventArgs>(SettingsWindow_SettingsUpdated);
			//sw.Unloaded += new RoutedEventHandler(SettingsWindow_Closed);
			sw.ShowDialog();
		}
	}

}
